import MapKit
import SwiftUI

struct ContentView_Preview: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ContentView: View {
    
    @StateObject var data = Data()
    
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.507222, longitude: -0.1275), span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5))

    var body: some View {
        NavigationView {
            List {
                ForEach(data.locations) { city in
                    NavigationLink(destination: DetailScreen(city: city)) {
                        Text(city.name)
                    }
                }
                .onDelete { index in
                    //data.locations.remove(at: index.first)
                }
            }
            .navigationTitle("All Pins")
        }.environmentObject(data)
    }
}
