//
//  MapView.swift
//  SwiftUIByExample
//
//  Created by Семён Кондаков on 30.09.2022.
//

import SwiftUI
import Foundation
import MapKit

struct MapView: View {
    @EnvironmentObject var data : Data
    @State var region: MKCoordinateRegion
    
    let annotationItems: [City]
    
    var body: some View {
        
        Map(coordinateRegion: $region, annotationItems: annotationItems) {
            MapPin(coordinate: $0.coordinate)
        }.onTapGesture {
            data.locations.append(City(name: String(data.locations.capacity), coordinate: CLLocationCoordinate2D(latitude: region.center.latitude, longitude: region.center.longitude)))
        }
    }
}
