//
//  DetailScreen.swift
//  SwiftUIByExample
//
//  Created by Семён Кондаков on 30.09.2022.
//

import SwiftUI
import MapKit

struct DetailScreen_Previews: PreviewProvider {
    static var previews: some View {
        DetailScreen(city: City(name: "London", coordinate: CLLocationCoordinate2D(latitude: 51.507222, longitude: -0.1275)))
            .padding(.top)
    }
}

struct City: Identifiable {
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
}

struct DetailScreen : View {
    let city : City
    
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.507222, longitude: -0.1275), span: MKCoordinateSpan(latitudeDelta: 10, longitudeDelta: 10))

    var body: some View {
        MapView(region: MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: city.coordinate.latitude, longitude: city.coordinate.longitude), span: MKCoordinateSpan(latitudeDelta: 10, longitudeDelta: 10)), annotationItems: [city])
    }
}
