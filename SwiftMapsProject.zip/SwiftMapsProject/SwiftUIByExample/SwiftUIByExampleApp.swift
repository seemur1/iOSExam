import SwiftUI

@main
struct SwiftUIByExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
